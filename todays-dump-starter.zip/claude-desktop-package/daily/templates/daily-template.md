---
type: daily
date: YYYY-MM-DD
---

# Today: [Day], [Month] [Date], [Year]

## Top 3 Priorities
1.
2.
3.

## Stale Items
<!-- AI populates with items sitting too long -->


## Brain Dump
<!-- Paste voice transcript or type thoughts here -->


## Tasks

### Must Do Today
- [ ]

### Should Do Today
- [ ]

### Could Do If Time
- [ ]

### Waiting On Others
- [ ]

## Meetings & Calls
| Time | Meeting | Notes |
|------|---------|-------|
|      |         |       |

## Quick Notes
<!-- Capture thoughts throughout the day -->


## End of Day Reflection
**What got done:**

**What blocked progress:**

**Tomorrow's focus:**
