---
type: daily
date: 2026-01-14
---

# Today: Tuesday, January 14, 2026

## Top 3 Priorities
1.
2.
3.

## Stale Items
<!-- AI populates this with items sitting too long -->


## Brain Dump
<!-- Paste your morning voice transcript or type your thoughts here -->
<!-- Example: "Need to send that proposal, forgot about dentist, meeting at 2pm..." -->



## Tasks

### Must Do Today
- [ ]

### Should Do Today
- [ ]

### Could Do If Time
- [ ]

### Waiting On Others
- [ ]

## Meetings & Calls
| Time | Meeting | Notes |
|------|---------|-------|
|      |         |       |

## Quick Notes
<!-- Capture thoughts throughout the day -->


## End of Day Reflection
**What got done:**

**What blocked progress:**

**Tomorrow's focus:**

---

*Ask Claude: "Process my brain dump" to get started*
